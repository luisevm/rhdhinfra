#!/bin/bash

# Running from same folder
cd $(dirname $0)

    CURL_DISABLE_SSL_VERIFICATION="-k"
    GIT_DISABLE_SSL_VERIFICATION="-c http.sslVerify=false"

INSTANCE_ID_COUNTER=$1
GITLAB_TOKEN=$2
GITLAB_NAMESPACE=$3
GITLAB_CRD_NAME=$4
GITLAB_PREFIX=$5

GITLAB_URL=https://$(oc get route -n $GITLAB_NAMESPACE -l app.kubernetes.io/name=${GITLAB_CRD_NAME},app=webservice -o jsonpath='{ .items[*].spec.host }')


# Create Groups
#if [ "0" == $(curl $CURL_DISABLE_SSL_VERIFICATION --header "PRIVATE-TOKEN: $GITLAB_TOKEN" -s "${GITLAB_URL}/api/v4/groups?search=team-a" | jq length) ]; then
    curl $CURL_DISABLE_SSL_VERIFICATION --request POST --header "PRIVATE-TOKEN: $GITLAB_TOKEN" \
    --header "Content-Type: application/json" \
    --data '{"path": "team-a", "name": "team-${INSTANCE_ID_COUNTER}", "visibility": "public" }' \
    "${GITLAB_URL}/api/v4/groups" &> /dev/null
#fi

TEAM_${INSTANCE_ID_COUNTER}_ID=$(curl $CURL_DISABLE_SSL_VERIFICATION --header "PRIVATE-TOKEN: $GITLAB_TOKEN" -s "${GITLAB_URL}/api/v4/groups?search=team-${INSTANCE_ID_COUNTER}" | jq -r '(.|first).id')

# Create Users
#if [ "0" == $(curl $CURL_DISABLE_SSL_VERIFICATION --header "PRIVATE-TOKEN: $GITLAB_TOKEN" -s "${GITLAB_URL}/api/v4/users?search=user1" | jq length) ]; then
    curl $CURL_DISABLE_SSL_VERIFICATION --request POST --header "PRIVATE-TOKEN: $GITLAB_TOKEN" \
        --header "Content-Type: application/json" \
        --data '{"email": "user1${INSTANCE_ID_COUNTER}@redhat.com", "password": "Password@12345","name": "user1${INSTANCE_ID_COUNTER}","username": "user1${INSTANCE_ID_COUNTER}", "skip_confirmation": "true" }' \
        "${GITLAB_URL}/api/v4/users" &> /dev/null
#fi

#if [ "0" == $(curl $CURL_DISABLE_SSL_VERIFICATION --header "PRIVATE-TOKEN: $GITLAB_TOKEN" -s "${GITLAB_URL}/api/v4/users?search=user2" | jq length) ]; then
    curl $CURL_DISABLE_SSL_VERIFICATION --request POST --header "PRIVATE-TOKEN: $GITLAB_TOKEN" \
        --header "Content-Type: application/json" \
        --data '{"email": "user2${INSTANCE_ID_COUNTER}@redhat.com", "password": "Password@12345","name": "user2${INSTANCE_ID_COUNTER}","username": "user2${INSTANCE_ID_COUNTER}", "skip_confirmation": "true" }' \
        "${GITLAB_URL}/api/v4/users" &> /dev/null
#fi

USER1${INSTANCE_ID_COUNTER}_ID=$(curl $CURL_DISABLE_SSL_VERIFICATION --header "PRIVATE-TOKEN: $GITLAB_TOKEN" -s "${GITLAB_URL}/api/v4/users?search=user1${INSTANCE_ID_COUNTER}" | jq -r '(.|first).id')
USER2${INSTANCE_ID_COUNTER}_ID=$(curl $CURL_DISABLE_SSL_VERIFICATION --header "PRIVATE-TOKEN: $GITLAB_TOKEN" -s "${GITLAB_URL}/api/v4/users?search=user2${INSTANCE_ID_COUNTER}" | jq -r '(.|first).id')

# Add users to group
#if [ "0" == $(curl $CURL_DISABLE_SSL_VERIFICATION --header "PRIVATE-TOKEN: $GITLAB_TOKEN" -s "${GITLAB_URL}/api/v4/groups/$TEAM_A_ID/members?user_ids=$USER1_ID" | jq length) ]; then
    curl $CURL_DISABLE_SSL_VERIFICATION --request POST --header "PRIVATE-TOKEN: $GITLAB_TOKEN" \
        --header "Content-Type: application/json" \
        --data "{\"user_id\": \"${USER1${INSTANCE_ID_COUNTER}_ID}\", \"access_level\": 50 }" \
        "${GITLAB_URL}/api/v4/groups/${TEAM_${INSTANCE_ID_COUNTER}_ID}/members" &> /dev/null
#fi

    curl $CURL_DISABLE_SSL_VERIFICATION --request POST --header "PRIVATE-TOKEN: $GITLAB_TOKEN" \
        --header "Content-Type: application/json" \
        --data "{\"user_id\": \"${USER2${INSTANCE_ID_COUNTER}_ID}\", \"access_level\": 50 }" \
        "${GITLAB_URL}/api/v4/groups/${TEAM_${INSTANCE_ID_COUNTER}_ID}/members" &> /dev/null



TEAM_A_ID=$(curl $CURL_DISABLE_SSL_VERIFICATION --header "PRIVATE-TOKEN: $GITLAB_TOKEN" -s "${GITLAB_URL}/api/v4/groups?search=team-a" | jq -r '(.|first).id')
TEAM_B_ID=$(curl $CURL_DISABLE_SSL_VERIFICATION --header "PRIVATE-TOKEN: $GITLAB_TOKEN" -s "${GITLAB_URL}/api/v4/groups?search=team-b" | jq -r '(.|first).id')

USER1_ID=$(curl $CURL_DISABLE_SSL_VERIFICATION --header "PRIVATE-TOKEN: $GITLAB_TOKEN" -s "${GITLAB_URL}/api/v4/users?search=user1" | jq -r '(.|first).id')
USER2_ID=$(curl $CURL_DISABLE_SSL_VERIFICATION --header "PRIVATE-TOKEN: $GITLAB_TOKEN" -s "${GITLAB_URL}/api/v4/users?search=user2" | jq -r '(.|first).id')

###### Delete the Project - quarkus-demo ######
#Find the Project ID
PROJECT_ID=$(curl $CURL_DISABLE_SSL_VERIFICATION --header "PRIVATE-TOKEN: $GITLAB_TOKEN" \
    "${GITLAB_URL}/api/v4/projects?search=quarkus_example" | jq '.[0].id')
#delete project
curl $CURL_DISABLE_SSL_VERIFICATION --request DELETE --header "PRIVATE-TOKEN: $GITLAB_TOKEN" \
     "${GITLAB_URL}/api/v4/projects/$PROJECT_ID"

#if [ "0" == $(curl $CURL_DISABLE_SSL_VERIFICATION --header "PRIVATE-TOKEN: $GITLAB_TOKEN" -s "${GITLAB_URL}/api/v4/projects?search=quarkus_example" | jq length) ]; then
# Create Projects - quarkus_example
    curl $CURL_DISABLE_SSL_VERIFICATION --request POST --header "PRIVATE-TOKEN: $GITLAB_TOKEN" \
        --header "Content-Type: application/json" \
        --data "{\"namespace_id\": \"$TEAM_A_ID\", \"name\": \"quarkus_example\", \"visibility\": \"public\" }" \
        "${GITLAB_URL}/api/v4/projects" &> /dev/null

# Create Projects - sample-app
if [ "0" == $(curl $CURL_DISABLE_SSL_VERIFICATION --header "PRIVATE-TOKEN: $GITLAB_TOKEN" -s "${GITLAB_URL}/api/v4/projects?search=sample-app" | jq length) ]; then
    curl $CURL_DISABLE_SSL_VERIFICATION --request POST --header "PRIVATE-TOKEN: $GITLAB_TOKEN" \
        --header "Content-Type: application/json" \
        --data "{\"namespace_id\": \"$TEAM_A_ID\", \"name\": \"sample-app\", \"visibility\": \"public\" }" \
        "${GITLAB_URL}/api/v4/projects" &> /dev/null
fi

#**************** Add sample-app to repo ***************
rm -rf /tmp/sample-app
mkdir -p /tmp/sample-app/

#team-a
git $GIT_DISABLE_SSL_VERIFICATION clone ${GITLAB_URL}/team-a/sample-app.git /tmp/sample-app
cp /mnt/vm/Var/my_git-clone/tap-demo/tap-demo7/tap-demo1/ansible/roles/gitlab/files/sample-app/catalog-info.yaml /mnt/vm/Var/my_git-clone/tap-demo/tap-demo10-lvemadomain-cert/tap-demo1/ansible/roles/gitlab/files/sample-app/catalog-info.yaml /mnt/vm/Var/my_git-clone/tap-demo/tap-demo7/tap-demo1/ansible/roles/gitlab/files/sample-app/users-groups.yaml /tmp/sample-app/
git $GIT_DISABLE_SSL_VERIFICATION -C /tmp/sample-app/ add .
git $GIT_DISABLE_SSL_VERIFICATION -C /tmp/sample-app commit -m "initial commit" --author="user1 <user1@redhat.com>"
echo enter user/password
git $GIT_DISABLE_SSL_VERIFICATION -C /tmp/sample-app push

#**********************************************************

#**************** Add quarkus-app to repo ***************
rm -rf /tmp/quarkus_example
mkdir -p /tmp/quarkus_example/

# Team-a
git $GIT_DISABLE_SSL_VERIFICATION clone ${GITLAB_URL}/team-a/quarkus_example.git /tmp/quarkus_example
cp -rf /tmp/quarkus-insecure-template/* /tmp/quarkus_example/
git $GIT_DISABLE_SSL_VERIFICATION -C /tmp/quarkus_example/ add .
git $GIT_DISABLE_SSL_VERIFICATION -C /tmp/quarkus_example commit -m "initial commit"
echo enter user1/password
git $GIT_DISABLE_SSL_VERIFICATION -C /tmp/quarkus_example push
rm -rf /tmp/quarkus-insecure-template

