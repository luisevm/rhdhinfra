# Sample Software Template

Sample Software template that:

- Defines a set of input parameters–in this case a name, owner, and a git repo to create.
- Publishes a copy of this repo to the new repo.
- Instantiates the component (a set of links).
