# Software Templates

Collection of Software Templates / Golden Path for Backstage.
