# Tekton CI Method

## Requirements

The Tekton CI Method will requires some steps before you are able to run

- Add Quay.io credentials as a secret
- Setup a GitHub webhook for push events
