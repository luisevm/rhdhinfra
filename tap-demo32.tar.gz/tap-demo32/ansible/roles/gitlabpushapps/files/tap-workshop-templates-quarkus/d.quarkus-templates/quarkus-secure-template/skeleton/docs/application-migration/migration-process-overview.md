# Migration Process Overview

The onboarding process consists of different personas and tasks.
The developer team will start their streamlined onboarding process following a few described steps.

![High-level onboarding process](high-level-onboarding-process.png)
