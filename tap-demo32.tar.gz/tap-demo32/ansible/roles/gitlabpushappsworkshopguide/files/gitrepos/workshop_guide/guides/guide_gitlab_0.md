# Part 0: Workshop Instructions

- The following image show the integration points of RHDH configured in this Workshop:

    ![Alt text](../images/guide_gitlab_0-1.png?raw=true "RHDH Configured Integrations") 

## Enviremont description

- **GitLab**: 
  - Each participant has two users (usermy_counter1 and usermy_counter2) created in GitLab, and these users are assigned to the group teammy_counter.
  - will see two repositories:  
    - rhdh_worshop_material: contains the templates and source code used in this Workshop
    - workshopguide: This repository contains the guide materials and instructions for running the Workshop.  

  - The following is a example of the two repositories created in GitLab
  
    ![Alt text](../images/guide_gitlab_0-0.png?raw=true "GitLab") 

- **OpenShift**:
  - The participants share an OCP cluster; therefore, to avoid overlapping namespaces, each participant will be assigned one namespace where the workloads and K8s manifest objects are deployed; the namespace assigned to you is projectmy_counter.

- **Red Hat Developer Hub**
  - Each participant has an instance of RHDH, which allows each to configure its RHDH instance independently from the other participants.

- **ArgoCD**
  - Each participant has an instance of ArgoCD.

- **Namespace**
  - Each participant has one namespace assigned with Admin permissions, all K8s objects are deployed into this namespace (project#)).

The following shows the details of how to log in to the systems. URL and users who can log in to OCP, RHDH, ArgoCD, and DevSpaces.

## URLs and Users

- **GitLab**
  - [URL RHDH](https://my_gitlab_domain)
  - Users:
    - usermy_counter1
    - usermy_counter2
  - Group:
      - teammy_counter
  - password: ***

- **Red Hat Developer Hub**      
  - [URL RHDH](https://backstage-developer-hub-my_rhdh_namespace.my_route_subdomain)
  - user admin: usera
  - password: ***

- **OpenShift** 
    - console
      - [URL OCP](https://console-openshift-console.my_route_subdomain)
      - user: usermy_counter1
      - password: ***
    - cli
      - https://my_server
      - user: usermy_counter1
      - password: ***

- **ArgoCD**
  - [URL ARGOCD](https://argocd-server-my_argocd_namespace.my_route_subdomain)
  - user: usermy_counter1
  - password: ***

- **DevSpaces**
  - [URL DEVSPACES](https://devspaces.my_route_subdomain)
  - user: usermy_counter1
  - password: ***



