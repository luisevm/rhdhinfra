# Part 4: Demo Golden Path Template: Deploying Quarkus application

## 1. Architecture:

- As a new developer, you are asked to join a project and implement a modification to a feature within a Quarkus-based service.
- To do that you are going to use a pre-configured Golden Path Template, which is going to streamline your onboarding process to your new project and perform the following in a self service manner:
  - The GPT is going to create two repositories in Gitlab, one for the application source code and the other for ArgoCD Manifests.
  - The next step in the GPT will instruct ArgoCD to create an application and all the specified resources in the Manifests in the target OpenShift cluster.
  - In this example we are using Helm charts as an input to ArgoCD to deploy:
      - A CI pipeline in Tekton to build your application and a webhook event listener that is triggered on every commit to the source code repository.
      - All the Kubernetes resources needed to deploy the quarkus-app, including a Deployment, Service and Route.

![Alt text](../images/architecture.png?raw=true "Architecture ") 

After you launched the GPT, feel free to explore both repositories by accessing the Source Code Repo GitOps Manifests Repo.



## 2. Import Quarkus Component to the Catalog

- Configure the location of the templates in the catalog definition, to import the components from the configured target URL and add the rules to allow importing all the defined objects. The Quarkus-app entities (Template, User, System, Group) will be imported to the RHDH Catalog. 

  - Configure the configmap app-config-rhdh:

    ```
    catalog:
      locations:
        - type: url
          target: https://gitlab.my_route_subdomain/teammy_counter/rhdh_worshop_material/-/blob/main/gitlab/templates/template_all.yaml
          rules:
            - type: url 
              allow: [Component, System, Group, Resource, Location, Template, API, User, Domain, Type]
    ```

    **RUN:**
 
    ```sh
    cd /tmp/workshopguide/
    ```

    **RUN:**
 
    ```sh
    oc apply -f ./app-config-gitlab/rhdh-app-configmap-9.yaml
    ```

- Navigate to the Catalog -> Template

  The Quarkus-app template should be visable

  ![Alt text](../images/quarkus-app-0.png?raw=true "Quarkus App Template") 

## 3. Launch the GPT

- To launch the Golden Path Template, navigate to the Catalogue -> Select Kind Template 

  ![Alt text](../images/quarkus-app-1.png?raw=true "Quarkus App Template") 

- Click on the Template named `Quarkus Application` 

  ![Alt text](../images/quarkus-app-2.png?raw=true "Quarkus App Template") 

- Click on `Launch Template`.
  - Here you will be presented with the formulary as described in the `Template`. 
  - You will be presented four formularies, you can keep the default values or customize them and press `next` to continue to the next formulary.
  - And finally click `Create` to apply.

  - NOTE: The deployed components names must be diferent.  

  ![Alt text](../images/quarkus-app-3.png?raw=true "Launch Template")

  ![Alt text](../images/quarkus-app-4.png?raw=true "Launch Template")

  ![Alt text](../images/quarkus-app-5.png?raw=true "Launch Template")

  ![Alt text](../images/quarkus-app-6.png?raw=true "Launch Template")

  ![Alt text](../images/quarkus-app-7.png?raw=true "Launch Template")

  - After clicking the Create button, RHDH will utilize the information you’ve provided to initiate the setup process as outlined in the selected Golden Path Template.
  - It will also register your application in the Catalog.

  - If you navigate to your [GitLab repository](https://gitlab.my_route_subdomain/dashboard/projects), two new repositories where created by the GPT:
    - `quarkus-app31` this repo contains the source code of the application
    - `quarkus-app31-gitops1 this repo contains the K8s objects to deploy the application in OpenShift

    ![Alt text](../images/quarkus-app-7.1.png?raw=true "GitLab")

  - Now, proceed by clicking the Open Component in catalog link.

## 4. Exploring the RHDH Dashboard
- On clicking the Open Component in catalog, the RHDH Dashboard will launch in a new tab.
- Here you have everything you need to work on your task and implement that new feature in the Quarkus application.
- Let’s take a moment to explore the different tabs available starting with the Overview tab.

### Overview tab
- The Overview tab displays a few tiles such as:
  - The Links tile: Gives you access to your Development Environment Red Hat OpenShift Dev Spaces. You can choose your preferred IDE, either Microsoft Visual Studio Code or JetBrains IntelliJ IDEA.
  - The About tile: Allows direct access to your application’s source code that was just created for you in GitLab via the View Source link and to the application documentation through the View TechDocs link.
  - The ArgoCD overview tile displays the current status of your application in ArgoCD (This may take a few minutes to sync and display the application status.).

  ![Alt text](../images/quarkus-app-8.png?raw=true "Launch Template")

- Let’s start by creating the workspace for your application by clicking on the OpenShift Dev Spaces (VScode) link.
  - This will launch the login process in a new tab. To login into OpenShift Dev Spaces,follow these step:
  - Choose to login with OpenShift
  - Then select the Htpasswd IdP and enter your OpenShift credentials with user my_org_users1 and password Password@12345
  - Authorize OpenShift Dev Spaces to access your account by clicking the Allow selected permissions button.
  - While OpenShift Dev Spaces is setting up your workspace, let’s take this opportunity to further explore the RHDH Dashboard.

#### Implementing a code change in OpenShift Dev Spaces
- Your IDE should now be loaded and ready in a browser tab.
- Click on the Yes, I Trust the Authors button to proceed.

- To accomplish your task, you are going to do three things:
  - Update the hello method in the ExampleResource.java class.
  - Update the JUnit test that verifies the output from this method.

	In case you are wondering, the JUnit test for the Hello method needs to be updated otherwise the Build step in our CI/CD pipeline will fail due to the discrepancy between the code and its test.

  - In your my-quarkus-app workspace, expand the folders src → main → java, and then open the file ExampleResource.java.
  - On line 18, replace the return message of the hello method from "Hello RESTEasy" to “Hello from RHDH”.

 ![Alt text](../images/quarkus-app-10.png?raw=true "Dev Spaces")

  - Next, update the JUnit test for this method.
    - Expand the folders src → test, and open the file ExampleResourceTest.java.
    - On line 14, change the expected text from "Hello RESTEasy" to “Hello from RHDH”.

  ![Alt text](../images/quarkus-app-11.png?raw=true "Dev Spaces")

  - Now, click on the Source Control icon in the left menu.

  ![Alt text](../images/quarkus-app-12.png?raw=true "Dev Spaces")

  - Config the git enviremont by configuring the git email and name

    ```sh
      git config --global user.name "Your Name" && \
      git config --global user.email "your.email@example.com"
    ```

  ![Alt text](../images/quarkus-app-13.png?raw=true "Dev Spaces")

- Enter the commit message “My First Commit” and then click on the Commit button.
- In the pop-up window that follows, click Yes to stage your changes.
- Finally, click on the `Sync Changes` button and in the pop-up the follows click OK to push your changes and complete the process.
- You will be asked to authenticate
  - Introduce the user my_org_users1
  - Introduct the password Password@12345
- You have now successfully implemented your change and updated the documentation in one commit.
- That commit should have triggered the build pipeline for the quarkus-app component through the event trigger.
- Switch back to RHDH Dashboard tab in your browser and select the CI tab from the top menu.

### CI tab
- The CI tab enables you to track the progress of the build pipeline for the quarkus_app component.
-	This is a simple Tekton pipeline, has tree steps: 
    - Clone the code git repository
    - Compile the code
    - Create the container image
- We could have used any other CI tool, and replace Tekton with another CI tool, by loading the proper dynamic plugin.
- Once the build pipeline execution is complete, let’s review the status of our application.
- Switch to the Topology tab.

  ![Alt text](../images/quarkus-app-14.png?raw=true "CI")

### Topology tab - Check application status
- In the Topology view, you will now see that our Pod is surrounded by a healthy blue ring, indicating that the Pod is running successfully. Note: It will depend on the Sync time of ArgoCD, for the pod to be created. 
- To open the application, click on the small icon located at the top right of the Pod.
- Your application will open in a new browser tab.

  ![Alt text](../images/quarkus-app-15.png?raw=true "Topology")

- Test the change you implemented by clicking on the 'hello' link; you should see the API return “Hello from RHDH” as expected.

  ![Alt text](../images/quarkus-app-16.png?raw=true "Topology")

  ![Alt text](../images/quarkus-app-17.png?raw=true "Topology")

- Next, switch to the CD tab. 

### CD tab

- Here, you will notice that the application is synced and showing a healthy status in ArgoCD.

  ![Alt text](../images/quarkus-app-18.png?raw=true "ArgoCD")

### Kubernetes tab

- Here you will see the K8s objects deployed.

  ![Alt text](../images/quarkus-app-19.png?raw=true "K8s")

### Api tab

- In the API view, you’ll find a lot of helpful information including access to source code, documentation, and a visual representation of relationships from the API’s perspective.
- To interact with your API, select the Definition tab.

  ![Alt text](../images/quarkus-app-20.png?raw=true "Api")

  ![Alt text](../images/quarkus-app-20.1.png?raw=true "Api")

  - Here you’ll find a Swagger UI, which provides an interactive interface for exploring and testing your API’s requests.
  
  ![Alt text](../images/quarkus-app-20.2.png?raw=true "Api")

### Dependencies tab

- The Dependencies view allows you to inspect your application’s relationships and dependencies.
  - In this example we can quickly understand that we have a component called quarkus-app31.
  - This component provides an API with the same name and is owned by the group named team2.

  ![Alt text](../images/quarkus-app-21.png?raw=true "Dependencies")

### Docs tab

- Traditionally, documentation is often stored in systems separate from the codebase..
- This separation can lead to inconsistencies, as developers need to update two different systems whenever changes are made to a component.
- Instead, RHDH adopts a documentation-as-code approach. This means documentation is stored alongside the code, albeit in a separate directory.
- As a result, developers can simultaneously create new features, modify code, update documentation, and commit all these changes to the repository in a single action.
 
  ![Alt text](../images/quarkus-app-22.png?raw=true "Docs")

### Search menu
- Search in RHDH is a powerful feature, offering centralized search capabilities that enable developers to quickly find the information they need.
- To navigate to the Search view, click on Search in the left menu.