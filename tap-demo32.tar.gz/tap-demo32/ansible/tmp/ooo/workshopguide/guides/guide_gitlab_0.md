# Part 0: Workshop Instructions

- The following image show the integration points of RHDH configured in this Workshop:

    ![Alt text](../images/guide_gitlab_0-1.png?raw=true "RHDH Configured Integrations") 

## Enviremont description

- **GitLab**: 
  - Each participant has two users (user51 and user52) created in GitLab, and these users are assigned to the group team5.
  - will see two repositories:  
    - rhdh_worshop_material: contains the templates and source code used in this Workshop
    - workshopguide: This repository contains the guide materials and instructions for running the Workshop.  

  - The following is a example of the two repositories created in GitLab
  
    ![Alt text](../images/guide_gitlab_0-0.png?raw=true "GitLab") 

- **OpenShift**:
  - The participants share an OCP cluster; therefore, to avoid overlapping namespaces, each participant will be assigned one namespace where the workloads and K8s manifest objects are deployed; the namespace assigned to you is project5.

- **Red Hat Developer Hub**
  - Each participant has an instance of RHDH, which allows each to configure its RHDH instance independently from the other participants.

- **ArgoCD**
  - Each participant has an instance of ArgoCD.

- **Namespace**
  - Each participant has one namespace assigned with Admin permissions, all K8s objects are deployed into this namespace (project#)).

The following shows the details of how to log in to the systems. URL and users who can log in to OCP, RHDH, ArgoCD, and DevSpaces.

## URLs and Users

- **GitLab**
  - [URL RHDH](https://gitlab.apps.rosa.p13.wk5s.p3.openshiftapps.com)
  - Users:
    - user51
    - user52
  - Group:
      - team5
  - password: ***

- **Red Hat Developer Hub**      
  - [URL RHDH](https://backstage-developer-hub-rhdhinstances5.apps.rosa.p13.wk5s.p3.openshiftapps.com)
  - user admin: usera
  - password: ***

- **OpenShift** 
    - console
      - [URL OCP](https://console-openshift-console.apps.rosa.p13.wk5s.p3.openshiftapps.com)
      - user: user51
      - password: ***
    - cli
      - https://https://api.p13.wk5s.p3.openshiftapps.com:443
      - user: user51
      - password: ***

- **ArgoCD**
  - [URL ARGOCD](https://argocd-server-argocdinstances5.apps.rosa.p13.wk5s.p3.openshiftapps.com)
  - user: user51
  - password: ***

- **DevSpaces**
  - [URL DEVSPACES](https://devspaces.apps.rosa.p13.wk5s.p3.openshiftapps.com)
  - user: user51
  - password: ***



