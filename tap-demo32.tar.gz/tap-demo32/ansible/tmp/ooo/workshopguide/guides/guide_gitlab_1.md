# Part 1: Administration of Red Hat Developer Hub

## 1. Pre Requesites
The main objective of this workshop is to demonstrate a proof of concept for the capabilities of the Red Hat Developer Hub (RHDH). 

Please note that RHDH can be installed using either an Operator or a Helm chart, and the configuration will vary based on the chosen installation method. For this workshop, we will assume that RHDH has been installed using the Operator. You can find the installation documentation here: [RHDH installation documentation](https://docs.redhat.com/en/documentation/red_hat_developer_hub/1.5/html/installing_red_hat_developer_hub_on_openshift_container_platform/index).

**RUN**:

  - Clone the following repo:
    
    ```sh
    git clone https://gitlab.apps.rosa.p13.wk5s.p3.openshiftapps.com/team5/workshopguide.git
    ```

**RUN**:

  - move inside the path:

    ```sh
    cd workshopguide
    ```

**RUN**:

  - Login to the OpenShift cluster:

    ```sh
    oc login -u user51 -p Password@12345 https://api.p13.wk5s.p3.openshiftapps.com:443
    ```

## 2. Base configuration of RHDH
The configuration and customization of RHDH are achieved using two config maps. One config map is for configuring the integrations of RHDH (e.g., with GitLab or Keycloak), while the other specifies which dynamic plugins RHDH should load. The names of these config maps are `app-config-red` and `dynamic-plugins-red`, respectively.

In addition, there is one secret named `secrets-rhdh`, which is created to protect sensitive information that should not be displayed in the `app-config-red` config map, such as tokens and passwords required for RHDH configurations.
The secret is created with a key named `BACKEND_SECRET`, this key will contain the password for the Backstage UI to authenticate with its backend.
 
**RUN**

```sh
oc apply -f ./app-config-gitlab/secrets-rhdh.yaml
```

Create the app-config-rhdh configmap:

```
kind: ConfigMap
apiVersion: v1
metadata:
  name: app-config-rhdh
  namespace: rhdhinstances5
data:
  app-config-rhdh.yaml: |
    app:
      title: My Red Hat Developer Hub Instance
      baseUrl: https://backstage-developer-hub-rhdhinstances5.apps.rosa.p13.wk5s.p3.openshiftapps.com
    backend:
      auth:
        externalAccess:
          - type: legacy
            options:
              subject: legacy-default-config
              secret: "${BACKEND_SECRET}"
      baseUrl: https://backstage-developer-hub-rhdhinstances5.apps.rosa.p13.wk5s.p3.openshiftapps.com
      cors:
        origin: https://backstage-developer-hub-rhdhinstances5.apps.rosa.p13.wk5s.p3.openshiftapps.com

    auth:
      environment: development
      providers:
        guest:
          dangerouslyAllowOutsideDevelopment: true
```

The baseUrl, is the FQDN of RHDH, i.e. the Route that is created on OCP to reach RHDH.

Note: the following configuration will allow you to authenticate and log to RHDH without requiring the integration with a proper identity provider (later in the workshop, we will integrate it with Keycloak). While this configuration is fine for testing, for production environments, ensure you secure users' authentication against RHDH.

```
    auth:
      environment: development
      providers:
        guest:
          dangerouslyAllowOutsideDevelopment: true
```

**RUN:**

```sh
oc apply -f ./app-config-gitlab/rhdh-app-configmap-1.yaml
```

Create the Backstage CRD to deploy an instance of RHDH.

```
apiVersion: rhdh.redhat.com/v1alpha2
kind: Backstage
metadata:
  name: developer-hub
  namespace: rhdhinstances5
spec:
  application:
    appConfig:
      configMaps:
        - name: app-config-rhdh
      mountPath: /opt/app-root/src
    extraEnvs:
      envs:
        # Disabling TLS verification
        - name: NODE_TLS_REJECT_UNAUTHORIZED
          value: '0'
      secrets:
        - name: secrets-rhdh
    extraFiles:
      mountPath: /opt/app-root/src
    replicas: 1
    route:
      enabled: true
  database:
    enableLocalDb: true
```

Note: The configmap app-config-rhdh was given as a reference in the BackStage CRD.

**RUN:**

```sh
oc create -f ./app-config-gitlab/backstage-1.yaml
```

The pod will roll out, and a new instance will be created with the configmap configuration applied.

Note: Red Hat Developer Hub has a slow startup as it is building and loading the dynamic plugins. Every time we apply a change in the configuration, an automatic redeploy will start, and it will take a few minutes until the new pod is ready to serve the request. Please be patient after any changes before confirming they are correctly applied.
More detailed information about this step here.https://docs.redhat.com/en/documentation/red_hat_developer_hub/1.4/html-single/configuring/index#provisioning-and-using-your-custom-configuration

Wait until the pods are Running:

**RUN**:

```sh
oc -n rhdhinstances5 get pods
```

The instance is deployed in the rhdhinstances5 namespace and available at:
```sh
echo https://$(oc -n rhdhinstances5 get route backstage-developer-hub -o jsonpath='{.spec.host}')
```

## 3. Keycloak Identity provider integration for users authentication with RHDH
This workshop is using Keycloak to authenticate users against RHDH, though other options are available, for more information check: 
[RHDH identity providers](https://docs.redhat.com/en/documentation/red_hat_developer_hub/1.5/html-single/authentication_in_red_hat_developer_hub/index)

For this example it is assumed that Keycloak is configured. And the variables are information that must be retrieved from Keycloack:
- KEYCLOAK_BASE_URL: FQDN of Keycloak, route to access keycloak
- KEYCLOAK_REALM: Realm name
- KEYCLOAK_CLIENT_ID: Client Id
- KEYCLOAK_CLIENT_SECRET: Client Secret

The following configuration must be added to the app-config-rhdh configmap:

```
    signInPage: oidc
    auth:
      environment: production
      session:
        secret: ${SESSION_SECRET}
      providers:
        oidc:
          production:
            metadataUrl: ${KEYCLOAK_BASE_URL}/realms/${KEYCLOAK_REALM}/.well-known/openid-configuration
            clientId: ${KEYCLOAK_CLIENT_ID}
            clientSecret: ${KEYCLOAK_CLIENT_SECRET}
            prompt: auto
            signIn:
              resolvers:
                - resolver: preferredUsernameMatchingUserEntityName 
        #guest:
        #  dangerouslyAllowOutsideDevelopment: true
```

Note: the parameter `environment` was modifyed from development to production, under this configuration the guest user is no longer allowed to authenticate with RHDH.

The secret secrets-rhdh must be updated with the keycloak keys configured in the configmap app-config-rhdh (${KEYCLOAK_BASE_URL}, ${KEYCLOAK_REALM}, ${KEYCLOAK_CLIENT_ID}, ${KEYCLOAK_CLIENT_SECRET}).

**RUN:**

```sh
oc -n rhdhinstances5 set data secret/secrets-rhdh KEYCLOAK_BASE_URL=https://keycloak-keycloak-system.apps.rosa.p13.wk5s.p3.openshiftapps.com
oc -n rhdhinstances5 set data secret/secrets-rhdh KEYCLOAK_CLIENT_SECRET=9IAuKgbRcEUTU4mjeUUTY25P6IKo0B6L
oc -n rhdhinstances5 set data secret/secrets-rhdh SESSION_SECRET=topSecretSecret
oc -n rhdhinstances5 set data secret/secrets-rhdh KEYCLOAK_CLIENT_ID=rhdh
oc -n rhdhinstances5 set data secret/secrets-rhdh KEYCLOAK_LOGIN_REALM=rhdh
oc -n rhdhinstances5 set data secret/secrets-rhdh KEYCLOAK_REALM=rhdh
```

Apply the modifyed configmap.

**RUN**:

```sh
oc apply -f ./app-config-gitlab/rhdh-app-configmap-2.yaml
```

Wait until RHDH new pod instance is RUNning:

**RUN**:

```sh
oc -n rhdhinstances5 get pods
```

Note: Once the RHDH pods are up, if you try to log in to RHDH, you will not be allowed to do so because the Keycloak users are not yet imported to RHDH. In order to import the Keycloak users, continue to the next exercise.

## 4. Configuration of Keycloak user/group autodiscovery

To achieve this configuration, a dynamic plugin needs to be enabled. As such, another config map must be created in order to enable the plugin to be enabled. The name of the new configmap will be dynamic-plugins-rhdh. The following is the configuration of the config map.

```
kind: ConfigMap
apiVersion: v1
metadata:
  name: dynamic-plugins-rhdh
  namespace: rhdhinstances5
data:
  dynamic-plugins.yaml: |
    includes:
      - dynamic-plugins.default.yaml
    plugins:
      - disabled: false
        package: ./dynamic-plugins/dist/backstage-community-plugin-catalog-backend-module-keycloak-dynamic
```

**RUN:**

```sh
oc apply -f ./app-config-gitlab/dynamic-plugins-rhdh-1.yaml
```

Add the following configuration to the configmap app-config-rhdh. Catalog → providers → keycloakOrg 

```
    catalog:
      providers:
        keycloakOrg:
          default:
            baseUrl: '${KEYCLOAK_BASE_URL}'
            clientId: '${KEYCLOAK_CLIENT_ID}'
            clientSecret: '${KEYCLOAK_CLIENT_SECRET}'
            loginRealm: '${KEYCLOAK_LOGIN_REALM}'
            realm: '${KEYCLOAK_REALM}'
            schedule:
              frequency:
                minutes: 1
              initialDelay:
                seconds: 15
              timeout:
                minutes: 1
```

**RUN:**

```sh
oc apply -f ./app-config-gitlab/rhdh-app-configmap-3.yaml
```

Configure the Backstage CRD with the configmap dynamic-plugins-rhdh, to load the dynamic plugins:

```
dynamicPluginsConfigMapName: dynamic-plugins-rhdh
```

**RUN**:

```sh
oc apply -f ./app-config-gitlab/backstage-2.yaml
```

Wait until RHDH new pod instance is RUNning:

**RUN**:

```sh
oc -n rhdhinstances5 get pods
```

## 5. Configuration of GitLab integration/Discovery

The GitLab integration has a special entity provider for discovering catalog entities from GitLab. The entity provider will crawl the GitLab instance and register entities matching the configured paths. This can be useful as an alternative to static locations or manually adding things to the catalog.
More information about Dynamic Plugins https://docs.redhat.com/en/documentation/red_hat_developer_hub/1.4/html-single/installing_and_viewing_plugins_in_red_hat_developer_hub/index

A Personal Access Token (PAT) is required to enable the GitLab integration and discovery capabilities.

A PAT has already been created on GitLab on your behalf. Nonetheless in the following, it is provided the process to create a PAT is in the menu Access Tokens of the GitLab user profile:
- GitLab UI navigation: Edit Profile -> Access Tokens -> Add new token
- name: <name-PAT>
- expiration date: Disabled it or just one in the future
- set the scopes: api, read_api, read_repository, write_repository

NOTE: Use the root user of GitLab to create this application.

- Add the PAT to the previously created secrets-rhdh secret:

  **RUN**

  ```sh
  oc -n rhdhinstances5 set data secret/secrets-rhdh GITLAB_TOKEN=KbfdXFhoX407c0v5ZP2Y
  ```

- Add to the app-config-rhdh ConfigMap:

  ```
      integrations:
        gitlab:
          - host: {{ gitlab_name_prefix }}{{ gitlab_crd_name }}.{{ route_subdomain_2 }}
            apiBaseUrl: https://{{ gitlab_name_prefix }}{{ gitlab_crd_name }}.{{ route_subdomain_2 }}/api/v4
            baseUrl: https://{{ gitlab_name_prefix }}{{ gitlab_crd_name }}.{{ route_subdomain_2 }}
            token: ${GITLAB_TOKEN}
  ```

  **RUN**:

  ```sh
  oc apply -f ./app-config-gitlab/rhdh-app-configmap-4.yaml
  ```

- Wait until RHDH new pod instance is RUNning:

  **RUN**:

  ```sh
  oc -n rhdhinstances5 get pods
  ```

## 6. Configuration of GitLab catalog autodiscovery

Once we have integrated GitLab with Red Hat Developer Hub, we need to enable the autodiscovery capabilities of this provider. This is useful to load our catalog with repositories already created in our GitLab server. 

- Configure the configmap app-config-rhdh:

  ```
          gitlab:
            myGitLab:
              host: {{ gitlab_name_prefix }}{{ gitlab_crd_name }}.{{ route_subdomain_2 }} # Identifies one of the hosts set up in the integrations
              apiBaseUrl: https://{{ gitlab_name_prefix }}{{ gitlab_crd_name }}.{{ route_subdomain_2 }}/api/v4
              branch: main                       # Optional. Used to discover on a specific branch
              fallbackBranch: master             # Optional. Fallback to be used if there is no default branch  configured at the Gitlab repository. It is only used, if `branch` is undefined. Uses `master` as default
              skipForkedRepos: false             # Optional. If the project is a fork, skip repository
              entityFilename: catalog-info.yaml  # Optional. Defaults to `catalog-info.yaml`
              projectPattern: '[\s\S]*'          # Optional. Filters found projects based on provided patter.  Defaults to `[\s\S]*`, which means to not filter anything
              schedule:                          # optional; same options as in TaskScheduleDefinition
                # supports cron, ISO duration, "human duration" as used in code
                frequency: { minutes: 5 }
                # supports ISO duration, "human duration" as used in code
                timeout: { minutes: 15 }
              orgEnabled: true
              #group: org/teams                  # Required for gitlab.com when `orgEnabled: true`. Optional for self managed. Must not end with slash. Accepts only groups under the provided path (which will be stripped)
              allowInherited: true               # Allow groups to be ingested even if there are no direct   members.
              groupPattern: '[\s\S]*'
              restrictUsersToGroup: false
  ```

  **RUN**:

  ```sh
  oc apply -f ./app-config-gitlab/rhdh-app-configmap-5.yaml
  ```

- Configure the dynamic plugin backstage-plugin-catalog-backend-module-gitlab-dynamic 

  ```
      - package: './dynamic-plugins/dist/backstage-plugin-catalog-backend-module-gitlab-dynamic'
        disabled: false
  ```

  **RUN**:

  ```sh
  oc apply -f ./app-config-gitlab/dynamic-plugins-rhdh-2.yaml
  ```

- Wait until RHDH new pod instance is Running:

  **RUN**:

  ```sh
  oc -n rhdhinstances5 get pods
  ```

## 7.Configuration of GitLab user/group autodiscovery

The Red Hat Developer Hub catalog can be set up to ingest organizational data, users, and groups directly from GitLab. The result is a User and Group entities hierarchy that mirrors your org setup.
Once we have integrated GitLab with Red Hat Developer Hub, we need to enable the autodiscovery capabilities of users and groups. That requires enabling the backstage-plugin-catalog-backend-module-gitlab-org-dynamic dynamic plugin provided by Red Hat Developer Hub.

- Configure the dynanic plugin configmap

  ```
        # GitLab Organization Discovery
        - package: './dynamic-plugins/dist/backstage-plugin-catalog-backend-module-gitlab-org-dynamic'
          disabled: false
        - package: './dynamic-plugins/dist/backstage-plugin-scaffolder-backend-module-gitlab-dynamic'
          disabled: false
  ```

  **RUN**

  ```sh
  oc apply -f ./app-config-gitlab/dynamic-plugins-rhdh-3.yaml
  ```

- Configure the configmap app-config-rhdh:

  ```
            orgEnabled: true
            #group: org/teams # Required for gitlab.com when `orgEnabled: true`. Optional for self managed. Must not end with slash. Accepts only groups under the provided path (which will be stripped)
            allowInherited: true               # Allow groups to be ingested even if there are no direct members.
            groupPattern: '[\s\S]*'
            restrictUsersToGroup: false
  ```

  **RUN**

  ```sh
  oc apply -f ./app-config-gitlab/rhdh-app-configmap-6.yaml
  ```

- Wait until RHDH new pod instance is Running:

  **RUN**:

  ```sh
  oc -n rhdhinstances5 get pods
  ```

## 8. Configuration of ArgoCD Plugin

This exercise focuses on integrating the ArgoCD plugin, allowing the RHDH users to visualize the state of the ArgoCD deployed K8s objects.

- Configure the configmap app-config-rhdh:

  ```
    argocd:
      appLocatorMethods:
        - type: config
          instances:
            - name: argocd
              url: https://argocd-server-{{ argocd_namespace }}.{{ route_subdomain }}
              username: admin
              password: {{ arcocd_admin_password }}
  ```
  The admin password must be captured from a secret; the following is how one can capture the password:

  NOTE: The command to capture the ArgoCD admin password is: `oc -n <argocd_namespace/openshift-gitops> extract secret/argocd-cluster --to=-`

  **RUN**

  ```sh
  oc apply -f ./app-config-gitlab/rhdh-app-configmap-7.yaml
  ```

- Configure Dynamic plugin CM

  ```
      - disabled: false
        package: ./dynamic-plugins/dist/roadiehq-scaffolder-backend-argocd-dynamic
      - disabled: false
        package: ./dynamic-plugins/dist/backstage-community-plugin-redhat-argocd
  ```

  **RUN**

  ```sh
  oc apply -f ./app-config-gitlab/dynamic-plugins-rhdh-4.yaml
  ```

- Wait until RHDH new pod instance is Running:

  **RUN**:

  ```sh
  oc -n rhdhinstances5 get pods
  ```

## 9.Configuration of Topology and Kubernetes Plugin

To enable these two plugins, RHDH must authenticate with OCP; this authentication will be done using a service account, and to enhance the SA security, only RBAC view access will be allowed to fetch information about the K8s objects. With this in mind, the SA will be attached to a Cluster Role view using the Cluster Role Binding.

**NOTE: The following steps have been completed on your behalf and are included to illustrate the required configuration. You only need to perform the step when instructed to `RUN`.**

- Create a service account

  A service account named local-cluster, has been created on your behalf in the RHDH namespace
  ```
  oc -n <rhdh_namespace> create serviceaccount local-cluster2
  ```

- Attach the SA to a ClusterRoleBinding:

    ```
    apiVersion: rbac.authorization.k8s.io/v1
    kind: ClusterRoleBinding
    metadata:
      name: rhdh-crb-view
    roleRef:
      apiGroup: rbac.authorization.k8s.io
      kind: ClusterRole
      name: view
    subjects:
      - kind: ServiceAccount
        name: local-cluster2
        namespace: <rhdh_namespace>
    ```

- Create a token:
  ```
  TOKEN=`oc create token {{ rhdh_sa_name }} --duration=100000h -n {{ rhdh_namespace }}`
  ```

- replace the SA and Token in the configmap app-config-rhdh


- Configure the configmap dynamic-plugins
    ```
      - disabled: false
        package: ./dynamic-plugins/dist/backstage-plugin-kubernetes-backend-dynamic
      - disabled: false
        package: ./dynamic-plugins/dist/backstage-plugin-kubernetes
      - disabled: false
        package: ./dynamic-plugins/dist/backstage-community-plugin-topology
    ```

    **RUN**

    ```sh
    oc apply -f ./app-config-gitlab/dynamic-plugins-rhdh-5.yaml
    ```

- Configure the configmap app-config-rhdh:

  To view the Tekton PipelineRUNs list in the side panel and the latest PipelineRUNs status in the Topology node decorator, you must add the following code to the kubernetes.customResources property in your app-config.yaml file:

    ```
    kubernetes:
      clusterLocatorMethods:
      - clusters:
        - authProvider: serviceAccount
          name: {{ rhdh_sa_name }}
          serviceAccountToken: {{ rhdh_sa_token }}
          skipTLSVerify: true
          url: {{ server }}
        type: config
      customResources:
      - apiVersion: v1beta1
        group: tekton.dev
        plural: pipelineRUNs
      - apiVersion: v1beta1
        group: tekton.dev
        plural: taskRUNs
      - apiVersion: v1
        group: route.openshift.io
        plural: routes
    ```

    **RUN**

    ```sh
    oc apply -f ./app-config-gitlab/rhdh-app-configmap-8.yaml
    ```

- Wait until RHDH new pod instance is RUNning:

  **RUN**:

  ```sh
  oc -n rhdhinstances5 get pods
  ```

## 10. Configure Tekton plugin

This plugin will get authenticated against OCP by using the same service account created in the previous step. Additionally, one has to enable the plugins.

- Configure the configmap dynamic-plugins-rhdh:

  ```
      - disabled: false
        package: ./dynamic-plugins/dist/backstage-community-plugin-tekton
  ```

  **RUN**

  ```sh
  oc apply -f ./app-config-gitlab/dynamic-plugins-rhdh-7.yaml
  ```

- Wait until RHDH new pod instance is Running:

  **RUN**:

  ```sh
  oc -n rhdhinstances5 get pods
  ```

## 11. Configuring TechDocs

TechDocs allows you to write markdown files (.md file extension) alongside your application's source code and store them either in the same repository where the application is maintained or on an external repository, which can then be referenced in the catalog YAML files.
The raw plain text source markdown files are then converted to HTML, and then displayed as HTML in the RHDH web UI.

By default, RHDH is configured to use an "all local" solution, meaning the code runs locally on the RHDH pod, and the HTML is stored in the container file system.
The "all local" approach is recommended only for small-sized installations of RHDH with a few components. This approach will not scale to large, medium-sized installations with hundreds or thousands of components. Recall that RHDH is running as a container, so this approach results is duplicating the HTML files and other processes across all the RHDH pods.

For a more scalable configuration, one can set up a CI/CD workflow to convert the markdown to HTML outside the RHDH pod and store the generated files in external Object storage. However, this configuration is outside of the scope of this workshop.

Out of the box, TechDocs is enabled and setup in RHDH with an "all local" configuration.

Tech Docs configuration consists of configuring the catalog-info.yaml with the annotation `backstage.io/techdocs-ref`, which points to the root of the document sources relative to the catalog-info.yaml file.

## 12. Configuring RBAC

Role-Based Access Control (RBAC) is a security concept that controls access to resources in a system, and specifies a mapping between users of the system, and the actions they can perform on resources in the system. You define roles with specific permissions, and then assign the roles to users.

The main reason to declare policy administrators is to allow a certain limited number of authenticated users to invoke the RBAC REST API. The actual policies are defined in a separate CSV file and referenced in the app-config-rhdh ConfigMap. This can be done by OpenShift platform or cluster administrators who have access to the namespace where RHDH is running. For more details refer to the [Authorization documentation](https://docs.redhat.com/en/documentation/red_hat_developer_hub/1.5/html-single/authorization_in_red_hat_developer_hub/index#proc-determining-policy-and-role-source)

To designate users as policy administrators, you need to add the following permission attribute to the `app-config-rhdh` ConfigMap: `permission.rbac.admin.users`. Make sure to include a valid authenticated user for the `admin.users` attribute. In this example, the user "usera" is granted RBAC administrator rights, meaning they have the ability to manage the RBAC configurations. Additionally, please note that by default, the administrator user does not have permission to create new entities, but they can configure a role that allows for this capability.

To apply RBAC in RHDH, you need to:
  - Configure RBAC in app-config-rhdh
  - Load Dynamic Plugin
  - Configure an authenticated user as a Policy Administrator
  - Configure policies in a CSV file and import it into RHDH

- Configure RBAC in app-config-rhdh

  ```
       catalog:
         providers:
         ...
       
       permission:
         enabled: true
         rbac:
           admin:
             users:
               - name: user:default/usera
  ```

    **RUN**

    ```sh
    oc apply -f ./app-config-gitlab/rhdh-app-configmap-8.1.yaml
    ```

- Load Dynamic Plugin

  ```
      - package: './dynamic-plugins/dist/backstage-community-plugin-rbac'
        disabled: false
  ```

  **RUN:**

  ```sh
  oc apply -f ./app-config-gitlab/dynamic-plugins-rhdh-8.yaml
  ```

  **RUN:**
  - Open an incognito window and login to RHDH:
    - https://backstage-developer-hub-rhdhinstances5.apps.rosa.p13.wk5s.p3.openshiftapps.com with userb (password: Password@12345)
    - Press on the Catalog and check that this user has restrictions in the kind of entities that it can see (only Components is available).
    - One can configure rules in the UI using the admin user, usera. in the menu Administration -> RBAC. 

    More fine grained RBAC Authorization can be configured by using the API or configuring rules using csv files, refer to the [documentation link](https://docs.redhat.com/en/documentation/red_hat_developer_hub/1.5/html-single/authorization_in_red_hat_developer_hub/index#proc-determining-policy-and-role-source)

- **To avoid the RBAC configuration to interfere with the rest of the Workshop, due to unset permissions, disable RBAC.**
    
**RUN:** 
```sh
oc apply -f ./app-config-gitlab/rhdh-app-configmap-8.2.yaml
```

## 13. Enabling High Availability

RHDH can provide high-availability capabilities, adding more replicas into the deployment topology. Adding more than one replica in the Backstage definition, your Red Hat Developer Hub will provide that capability. For more details refer to the documentation link. [documentation link](https://docs.redhat.com/en/documentation/red_hat_developer_hub/1.5/html-single/configuring_red_hat_developer_hub/index#HighAvailability)

**RUN:**
```sh
oc apply -f ./app-config-gitlab/backstage-3.yaml
```

## 14. Complete configuration

If you missed any of the previous steps, or want to continue to the next exercises:

**RUN:**

- Create Secret secrets-rhdh
 
    ```sh
    oc -n rhdhinstances5 create secret generic secrets-rhdh
    
    oc -n rhdhinstances5 set data secret/secrets-rhdh KEYCLOAK_BASE_URL=https://keycloak-keycloak-system.apps.rosa.p13.wk5s.p3.openshiftapps.com
    oc -n rhdhinstances5 set data secret/secrets-rhdh KEYCLOAK_CLIENT_SECRET=9IAuKgbRcEUTU4mjeUUTY25P6IKo0B6L
    oc -n rhdhinstances5 set data secret/secrets-rhdh SESSION_SECRET=topSecretSecret
    oc -n rhdhinstances5 set data secret/secrets-rhdh KEYCLOAK_CLIENT_ID=rhdh
    oc -n rhdhinstances5 set data secret/secrets-rhdh KEYCLOAK_LOGIN_REALM=rhdh
    oc -n rhdhinstances5 set data secret/secrets-rhdh KEYCLOAK_REALM=rhdh
    oc -n rhdhinstances5 set data secret/secrets-rhdh GITLAB_TOKEN=KbfdXFhoX407c0v5ZP2Y
    oc -n rhdhinstances5 set data secret/secrets-rhdh BACKEND_SECRET=gandanoia
    ```

- Clone git repo
    ```sh
    cd /tmp
    ```

    ```sh
    git clone https://gitlab.apps.rosa.p13.wk5s.p3.openshiftapps.com/team5/workshopguide.git
    ```

- cd directory

    ```sh
    cd workshopguide
    ```

- Deploy ConfigMap app-config-rhdh

    ```sh
    oc apply -f ./app-config-gitlab/rhdh-app-configmap-9.yaml
    ```

- Deploy ConfigMap dynamic-plugins-rhdh

    ```sh
    oc apply -f ./app-config-gitlab/dynamic-plugins-rhdh-8.yaml
    ```

- Deploy Backstage

    ```sh
    oc apply -f ./app-config-gitlab/backstage-3.yaml
    ```

- Wait until the pods are Running:

    ```sh
    oc -n rhdhinstances5 get pods
    ```
