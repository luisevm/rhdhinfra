# Part 2: Catalog

## 1. Concepts and Terminology

The Catalog is a collection of Components, also called Entities. Entities can be of different types, corresponding to APIs, internal and external applications, templates, locations where other entities can be found, and many more.
This section walks you through a hands-on experience of populating the Catalog with different types of entities.

The following are some of the most commonly used types of entities in the Catalog:

**Components**

A Component is a generic piece of software (web app, mobile app, back-end service, front-end app, CLI tools, and more) that can be tracked in a version control system like Git. A component can implement APIs that other components consume or consume APIs implemented by different components.

**API**

APIs are implemented by components and provide formal interfaces between them. APIs are described using different standards (REST, gRPC, GraphQL, and more) that are ideally machine-readable. RHDH supports documenting, importing, indexing, and searching APIs of many different types and exposes them in the catalog for discovery and exploration by developers across your organization.

**Resource**
 
Resources are infrastructure dependencies a component needs to operate at runtime (such as Databases, Message Queues, Storage systems, Servers, VMs, and more).

**User**

A user represents a person, such as an employee, or external users like contractors or anyone you want to track in RHDH who is part of your software ecosystem.

**Group**

A group represents a set of Users logically grouped into a parent entity (development teams, business units, and more).

**Location**

A location acts as a proxy that references other locations to locate catalog data (YAML files).

**Template**

A Template is an RHDH entity that describes a set of source files and structure, from which you can create instances of applications, services, CI/CD pipelines, Infrastructure as Code (IaC) playbooks, operating system and virtual machine provisioning scripts, and more. These instances are then automatically populated and tracked in the RHDH Software Catalog. A Template can contain a mix of source code, configuration files, build system configuration, and all the dependencies that are required for an application or a service. The Template is parsed by RHDH, which then provides a visual interface to create application instances from it. Dynamic parts that need user input are modeled as Parameters in the template. Input forms corresponding to the parameters are automatically created by RHDH in the front-end portal.
System 
A System is a logical grouping of Resources and Components that provides one or more APIs. A System abstracts away the resources and private APIs between the components for any consumers. This means that as the owner, you can evolve the implementation, in terms of components and resources, without your consumers being affected.
Domain 
While Systems are the basic level of encapsulation for related entities, grouping a collection of systems that share terminology, domain models, metrics, KPIs, business purposes, or documentation into a higher-level abstraction called a Domain is often useful.

## 2. Import Components to the Catalog

Components to be populated in the Catalog are described using YAML files, inspired mainly by Kubernetes configuration files. These YAML files are typically stored in a Git repository alongside the component they describe and are served remotely over HTTP/HTTPS to RHDH for bulk import. There are several ways of importing/registering the Components into the Catalog.

The Components can be manually registered from the Catalog Create... menu. The Register Existing Component button opens a wizard to register the component from the remote URL. 

Another alternative is to configure the location of the templates in the catalog definition.

```
catalog:
  locations:
    - type: url
      target: <location of your YAML>
      rules:
        - type: url 
          allow: [Component, System, Group, Resource, Location, Template, API, User, Domain, Type]
    - type: url
      target: <location of your YAML>
      rules:
        - type: url 
          allow: [Component, System, Group, Resource, Location, Template, API, User, Domain, Type]

```

However, adding a lot of "targets" in this manner is not recommended, as you need to redeploy the RHDH container for the changes to take effect.
`Instead`, you can provide the URL of a top-level YAML file that includes other YAML files. This way, you can change the included YAML files without updating the app-config YAML files.
See https://github.com/janus-idp/backstage-showcase/blob/main/app-config.yaml#L154 for an example of this technique.

By default, the catalog only allows the ingestion of entities with the kind Component, API, and Location. To allow entities of other kinds to be added, you must add "rules" to the catalog. Rules are added either in a separate catalog.rules key or added to statically configured locations.

## 3.The catalog-info.yaml

The catalog-info.yaml file is the primary mechanism through which components are
described and added to the catalog. This YAML file contains metadata about a software
component, allowing Developer Hub to understand, categorize, and display information about
the component. The structure and contents of the file enable integration of components into
the Developer Hub ecosystem. The following section describes how the catalog-info.yaml
file describes components.
It’s like a business card for your service or project — RHDH reads it to understand: What the entity is (e.g., a service, a library), who owns it, where its source code lives, how to link it to CI/CD, docs, Kubernetes, topology, etc.

## 4.Exercise: Importing Components from the catalog-info.yaml into the RHDH Catalog via the UI 

RHDH doesn't know where your service is running unless you tell it how to identify your workloads in Kubernetes. Therefore, the catalog-info.yaml uses annotations to map catalog entities (like a Component) to Kubernetes resources. It matches specific annotations in the entity's YAML to labels in your Kubernetes objects (like Deployments, Pods, etc.).

The objective of this exercise is to deploy a simple nginx based web application, configure the annotations in the catalog-info, and enable the Topology plugin, which will allow you to show the resources deployed in the K8s with a label matching the annotations from the catalog-info.yaml.

**Steps of the exercise:**

**a.Log in to the OpenShift cluster**

- NOTE: All your deployments will be done in the namespace XXXXXXXXX/

    **Run:**

    ```sh
    oc login -u user51 -p Password@12345 https://api.p13.wk5s.p3.openshiftapps.com:443
    ```

**b.Clone the repository**
- Clone the repository

    **RUN:**

    ```sh
    cd /tmp
    ```

    ```sh
    git clone https://gitlab.apps.rosa.p13.wk5s.p3.openshiftapps.com/team5/rhdh_worshop_material.git
    ```

**c.Configure annotation on the catalog-info.yaml file**

- In your catalog-info.yaml files, you need to enable the backstage.io/kubernetes-id annotation and the backstage.io/kubernetes-label-selector under your components metadata field. Don't forget that the corresponding labels must exist in the Kubernetes resources.

    **RUN:**

    - Edit the catalog-info.yaml file and add the annotation.

      ```sh
      vi gitlab/templates/nginx-example/catalog-info.yaml
      ```

    - Uncomment the three annotations
      
      ```sh
      annotations:
        backstage.io/kubernetes-id: 'nginx-ex-<instance>'
        backstage.io/kubernetes-namespace: <instance>
        backstage.io/kubernetes-label-selector: 'app=nginx<instance>'
      ```

    - Finaly save the file


**d.Label the K8s manifest files**

- Correspondingly, on the Kubernetes resource side, you need to add a:
    - backstage.io/kubernetes-id label to the resources you want to track in RHDH
    - app: nginx<instance>

    **RUN:**

    - Inspect the K8s Deployment manifest file and uncomment the two labels:

      ```sh
      vi gitlab/templates/nginx-example/nginx-deploy.yaml
      ```

    - Uncomment three labels
      
      ```sh
      metadata:
        labels:
          app: nginx<instance>
          backstage.io/kubernetes-id: nginx-ex-<instance>
      ...
      spec:
        template:
          metadata:
            labels:
              app: nginx<instance>
      ```

    - Deploy Nginx
      ```sh
      oc apply -f gitlab/templates/nginx-example/nginx-deploy.yaml
      ```  

    - Two pods should be running
      ```sh
      oc -n namespace_dev get pods
      ```

**e.Push your code change to git**

- Push code
    
    **RUN:**
    
    ```sh
    git add *
    git commit -m "updated nginx proj"
    git push
    ```

**e.Manually Import the component into the RHDH Catalog using the UI**

- Navigate to: RHDH UI -> Catalog -> Create > Register Existing
- Provide the full path were the Nginx catalog-info.yml file is saved. i.e:
https://gitlab.apps.rosa.p13.wk5s.p3.openshiftapps.com/team5/rhdh_worshop_material/-/blob/main/gitlab/templates/nginx-example/catalog-info.yaml

- After the component is imported, click on view component.

![Alt text](../images/nginx-catalog-info_1.png?raw=true "Nginx catalog-info") 

![Alt text](../images/nginx-catalog-info_2.png?raw=true "Nginx catalog-info") 

**f.Verify that on the Kubernetes and Topology tab you can visualize the deployment pods state**

![Alt text](../images/nginx-catalog-info_3.png?raw=true "Nginx catalog-info") 

![Alt text](../images/nginx-catalog-info_4.png?raw=true "Nginx catalog-info") 

![Alt text](../images/nginx-catalog-info_5.png?raw=true "Nginx catalog-info") 

To enable the visualization of other plugins, such as Kubernetes, Tekton or CD/ArgoCD, these must be configured as well in the form of annotations in catalog-info.yaml and on the resources to track.
