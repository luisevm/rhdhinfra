
# Index

## [Part 0: Workshop Instructions](guide_gitlab_0.md)
1. Enviremont description
1. URLs and Users

## [Part 1: Administration of Red Hat Developer Hub](guide_gitlab_1.md)
1. Pre Requesites
1. Base configuration of RHDH
1. Keycloak Identity provider integration for users authentication with RHDH
1. Configuration of Keycloak user/group autodiscovery
1. Configuration of GitLab integration/Discovery
1. Configuration of GitLab catalog autodiscovery
1. Configuration of GitLab user/group autodiscovery
1. Configuration of ArgoCD Plugin
1. Configuration of Topology and Kubernetes Plugin
1. Configure Tekton plugin
1. Configuring TechDocs
1. Configuration of RHDH RBAC
1. Enabling High Availability
1. Complete configuration

## [Part 2: Catalog](guide_gitlab_2.md)
1. Concepts and Terminology
1. Import Components to the Catalog
1. The catalog-info.yaml
1. Exercise: Importing Components cintained in catalog-info.yaml file to the Catalog via the UI 

## [Part 3: Craft your first Golden Path Template](guide_gitlab_3.md)
1. Hello World Template
1. Test Hello World Template
1. Modify Hello World Template

## [Part 4: Demo Golden Path Template: Deploying Quarkus application](guide_gitlab_4.md)
1. Architecture
1. Import Quarkus Component to the Catalog
1. Launch the GPT
1. Exploring the RHDH Dashboard

## [Part 5: References](guide_gitlab_5.md)
- ??????
- Documentation Red Hat
- List Dynamic Plugins
- 
- 